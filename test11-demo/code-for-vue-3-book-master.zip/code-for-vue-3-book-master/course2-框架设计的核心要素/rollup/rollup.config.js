const config = {
  input: 'input.js',
  output: {
    file: 'output.js',
    format: 'iife'
  }
}

export default config