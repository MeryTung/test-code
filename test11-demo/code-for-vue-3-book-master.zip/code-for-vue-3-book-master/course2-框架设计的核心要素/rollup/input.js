import {foo} from './utils'

foo()