export function foo(obj) {
  obj && obj.foo
}
export function bar() {
  console.log()
}
