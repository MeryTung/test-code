(function () {
  'use strict';

  function foo(obj) {
    obj && obj.foo;
  }

  foo();

}());
